<?php

include_once 'header.php';



?>
<!DOCTYPE html>
<html lang="en">
        <head>
  <link rel="stylesheet" href="css/style2.css">
            <meta charset="UTF-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
               <title>welcome to our Website</title>


        </head>
<body>
  <section class="categories">
       <div class="container">
           <h2 class="text-center">Explore Clothing</h2>

           <a href="man.php">
           <div class="box-3 float-container">
               <img src="man2.jpg"  class="img-responsive img-curve">

               <h3 class="float-text text-white">Men Clothing</h3>
           </div>
           </a>

           <a href="woman.php">
           <div class="box-3 float-container">
               <img src="w5.jpg"  class="img-responsive img-curve">

               <h3 class="float-text text-white">Women Clothing</h3>
           </div>
           </a>

           <a href="kids.php">
           <div class="box-3 float-container">
               <img src="k2.jpg"  class="img-responsive img-curve">

               <h3 class="float-text text-white">Kids Clothing</h3>
           </div>
           </a>

           <div class="clearfix"></div>
       </div>
   </section>


</body>
</html>
